<?php
header("Access-Control-Allow-Origin: *");

$dado = rand(1, 6);
echo $dado;
?>