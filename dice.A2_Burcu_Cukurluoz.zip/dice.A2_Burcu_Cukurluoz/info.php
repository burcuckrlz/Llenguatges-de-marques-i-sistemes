<?php
header("Access-Control-Allow-Origin: *");

echo "IP del servidor: " . ($_SERVER['SERVER_ADDR'] ?? 'No disponible') . "<br>";
echo "Nombre del host: " . ($_SERVER['SERVER_NAME'] ?? 'No disponible') . "<br>";
echo "Software del servidor: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'No disponible') . "<br>";
echo "IP del cliente: " . ($_SERVER['REMOTE_ADDR'] ?? 'No disponible') . "<br>";
?>