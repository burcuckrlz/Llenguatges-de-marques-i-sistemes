window.onload = function () {
    let button = document.querySelector("#nuevaTirada");
    button.addEventListener('click', nuevaTirada);
};

async function nuevaTirada() {
    let response1 = await fetch("http://localhost/dice/dice.php");
    let dado1 = await response1.text();

    let response2 = await fetch("http://localhost/dice/dice.php");
    let dado2 = await response2.text();

    actualizarDados(dado1, dado2);
}

function actualizarDados(dado1, dado2) {
    document.querySelector('.dice:first-child img').src = "assets/" + dado1 + ".webp";
    document.querySelector('.dice:last-child img').src = "assets/" + dado2 + ".webp";
}