<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>table {border-collapse: collapse;}
        td {
            border: 2px solid blue;
            padding: 5px;
        }</style>

</head>
<body>
    <p>tasca 1</p>
    <table>
        <tr>
        <?php
            for ($i = 1; $i <= 10; $i++) {
                echo "<td>$i</td>";
            }
        ?>
        </tr>
    </table>
    <p>tasca 2</p>
    <table>
        <?php
            for ($j = 1; $j <= 10; $j++) { 
                echo "<tr><td>$j</td></tr>";
            }
        ?>
    </table>
    
    <p>tasca 3</p>
    <?php
    $dado = rand(1, 30);
    $dado2 = rand(1, 30);
    $dado3 = rand(1, 30);
    $dado4 = rand(1, 30);
    $dado5 = rand(1, 30);
    $dado6 = rand(1, 30);
    $dado7 = rand(1, 30);
    $dado8 = rand(1, 30);
    $dado9 = rand(1, 30);
    $dado10 = rand(1, 30);


    $productos = array($dado,$dado2,$dado3,$dado4,$dado5,$dado6,$dado7,$dado8,$dado9,$dado10);
    $numElementos = count($productos);

    $total = 0;
    for ($i = 0; $i < $numElementos; $i++) {
    echo $productos[$i];
    echo "<br>";
    $total = $total + $productos[$i];
    }
    echo "el valor total es ".$total;
    echo "<br>";
    echo "la media es ". $media = $total / 10;
 ?>
    <br>
    <p>tasca 4</p>

    <?php
    $PaisesCapitales =array("Italy"=>"Rome", "Luxembourg"=>"Luxembourg", "Belgium"=> "Brussels", "Denmark"=>"Copenhagen",
     "Finland"=>"Helsinki", "France" => "Paris", "Slovakia"=>"Bratislava", "Slovenia"=>"Ljubljana",
      "Germany" => "Berlin", "Greece" => "Athens", "Ireland"=>"Dublin", "Netherlands"=>"Amsterdam", "Portugal"=>"Lisbon"
      , "Spain"=>"Madrid", "Sweden"=>"Stockholm", "United Kingdom"=>"London", "Cyprus"=>"Nicosia", "Lithuania"=>"Vilnius",
       "Czech Republic"=>"Prague", "Estonia"=>"Tallin", "Hungary"=>"Budapest", "Latvia"=>"Riga", "Malta"=>"Valetta", "Austria" => "Vienna", "Poland"=>"Warsaw");
    
       foreach($PaisesCapitales as $clave => $valor){
        echo "La capital de $clave es $valor";
        echo "<br>";
    }    
    ?>

</body>
</html>