<?php
header("Access-Control-Allow-Origin: *");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    echo "Bienvenido, $nombre $apellido!";
} else {
    echo "Método no permitido";
}
?>
