window.onload = function(){
    let botoEnviar = document.querySelector('button');
    botoEnviar.addEventListener('click',enviarForm)
}

async function enviarForm(event){
    event.preventDefault();
    let form = document.querySelector('#form');
    let options = {
        method : 'POST',
        body: new FormData(form)
    }
    let response = await fetch('http://localhost/backend/procesar.php',options);
    let data = await response.text();
    console.log(data);
}